package id.ts.overlay;

import android.app.*;
import android.os.*;
import android.content.*;
import android.net.Uri;
import android.graphics.*;
import android.graphics.drawable.GradientDrawable;
import android.provider.Settings;
import android.view.*;
import android.widget.*;
import android.text.*;
import android.text.style.*;
import org.json.*;
import okhttp3.*;
import java.text.*;
import java.util.*;
import java.util.concurrent.*;

public class MainActivity extends Activity {
    int dp(float n) {
        return (int)(n * getResources().getDisplayMetrics().density + 0.5f);
    }

    LinearLayout root;
    TextView clock, display, statusView, updateView;
    Handler handler = new Handler(Looper.getMainLooper());
    OkHttpClient client;
    WebSocket socket;
    boolean active = false;
    double buy = 0, sell = 0, previousBuy = 0;
    String updated = "-", status = "Menghubungkan Treasury...";
    Runnable reconnect;

    Runnable clockTick = new Runnable() {
        public void run() {
            if (!active) return;
            if (clock != null) {
                clock.setText(new SimpleDateFormat("HH:mm:ss",
                    Locale.getDefault()).format(new Date()));
            }
            handler.postDelayed(this, 1000);
        }
    };

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        active = true;
        getWindow().setStatusBarColor(Color.rgb(17,24,39));
        getWindow().setNavigationBarColor(Color.rgb(17,24,39));

        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(16),dp(18),dp(16),dp(12));
        root.setBackgroundColor(Color.rgb(11,18,32));

        LinearLayout header = new LinearLayout(this);
        header.setGravity(Gravity.CENTER_VERTICAL);

        TextView title = new TextView(this);
        title.setText("CUAN EXECUTOR");
        title.setTextColor(Color.rgb(245,200,90));
        title.setTextSize(22);
        title.setTypeface(null,1);
        header.addView(title,new LinearLayout.LayoutParams(0,-2,1));

        TextView menu = new TextView(this);
        menu.setText("⋮");
        menu.setTextSize(30);
        menu.setTextColor(Color.WHITE);
        menu.setPadding(dp(12),0,dp(4),0);
        header.addView(menu);
        root.addView(header);

        menu.setOnClickListener(v -> {
            PopupMenu popup = new PopupMenu(this,menu);
            popup.getMenu().add("US NEWS MINGGUAN").setOnMenuItemClickListener(item -> {
                openNews("weekly"); return true;
            });
            popup.getMenu().add("AKTIFKAN OVERLAY").setOnMenuItemClickListener(item -> {
                startOverlay(); return true;
            });
            popup.getMenu().add("HENTIKAN OVERLAY").setOnMenuItemClickListener(item -> {
                stopService(new Intent(this,PriceOverlayService.class));
                Toast.makeText(this,"Overlay dihentikan",Toast.LENGTH_SHORT).show();
                return true;
            });
            popup.getMenu().add("KELUAR APLIKASI").setOnMenuItemClickListener(item -> {
                active = false;
                if (socket != null) socket.close(1000,"App closed");
                stopService(new Intent(this,PriceOverlayService.class));
                finishAndRemoveTask();
                return true;
            });
            popup.show();
        });

        TextView subtitle = new TextView(this);
        subtitle.setText("PREMIUM  •  SIMPLE  •  HEMAT DAYA");
        subtitle.setTextColor(Color.LTGRAY);
        subtitle.setTextSize(11);
        subtitle.setPadding(0,dp(4),0,dp(16));
        subtitle.setVisibility(View.GONE);
        root.addView(subtitle);

        LinearLayout panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setPadding(dp(14),dp(12),dp(14),dp(14));
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(Color.rgb(18,30,48));
        bg.setCornerRadius(dp(14));
        bg.setStroke(dp(1),Color.rgb(43,57,77));
        panel.setBackground(bg);
        root.addView(panel,new LinearLayout.LayoutParams(-1,-2));

        LinearLayout timeRow = new LinearLayout(this);
        timeRow.setGravity(Gravity.CENTER_VERTICAL);
        TextView timeLabel = new TextView(this);
        timeLabel.setText("WAKTU WIB");
        timeLabel.setTextColor(Color.LTGRAY);
        timeLabel.setTextSize(12);
        timeRow.addView(timeLabel,new LinearLayout.LayoutParams(0,-2,1));

        clock = new TextView(this);
        clock.setTextColor(Color.rgb(100,220,160));
        clock.setTextSize(28);
        clock.setTypeface(null,1);
        timeRow.addView(clock);
        timeRow.setVisibility(View.GONE);
        panel.addView(timeRow);

        display = new TextView(this);
        display.setTextColor(Color.WHITE);
        display.setTextSize(19);
        display.setLineSpacing(dp(3),1f);
        display.setPadding(0,dp(10),0,0);
        panel.addView(display);

        updateView = new TextView(this);
        updateView.setTextColor(Color.LTGRAY);
        updateView.setTextSize(12);
        updateView.setPadding(0,dp(12),0,dp(3));
        updateView.setVisibility(View.GONE);
        panel.addView(updateView);

        statusView = new TextView(this);
        statusView.setTextColor(Color.rgb(100,220,160));
        statusView.setTextSize(12);
        statusView.setVisibility(View.GONE);
        panel.addView(statusView);

        TextView note = new TextView(this);
        note.setText("US NEWS hari ini tampil di floating overlay.");
        note.setTextColor(Color.GRAY);
        note.setTextSize(11);
        note.setPadding(0,dp(14),0,0);
        note.setVisibility(View.GONE);
        root.addView(note);

        TextView footer = new TextView(this);
        footer.setText("TS GOLD PULSE PRO  •  LIVE PRICE");
        footer.setTextColor(Color.GRAY);
        footer.setTextSize(10);
        footer.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams fp = new LinearLayout.LayoutParams(-1,-2);
        fp.topMargin = dp(18);
        footer.setVisibility(View.GONE);
        root.addView(footer,fp);

        setContentView(root);
        render();
        handler.post(clockTick);
        connectPusher();
    }

    void openNews(String period) {
        Intent i = new Intent(this,USNewsActivity.class);
        i.putExtra("period",period);
        startActivity(i);
    }

    void startOverlay() {
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this,"Izinkan overlay di pengaturan",Toast.LENGTH_SHORT).show();
            Intent i = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:"+getPackageName()));
            startActivity(i);
            return;
        }
        Intent i = new Intent(this,PriceOverlayService.class);
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(i);
        else startService(i);
        Toast.makeText(this,"Overlay diaktifkan",Toast.LENGTH_SHORT).show();
    }

    String rupiah(double n) {
        return NumberFormat.getIntegerInstance(new Locale("id","ID"))
            .format(Math.round(n));
    }

    void render() {
        if (display == null) return;
        SpannableStringBuilder b = new SpannableStringBuilder();

        if (buy <= 0 || sell <= 0) {
            b.append("🟢 BUY\nMenunggu data\n\n🔴 SELL\nMenunggu data\n\nSPREAD\nMenunggu data");
        } else {
            b.append("🟢 BUY\n");
            int a = b.length();
            b.append("Rp").append(rupiah(buy));
            int buyColor = previousBuy == 0 || buy == previousBuy
                ? Color.rgb(245, 200, 90)
                : (buy > previousBuy ? Color.rgb(65, 220, 145)
                                     : Color.rgb(255, 90, 95));
            b.setSpan(new android.text.style.ForegroundColorSpan(buyColor),
                a, b.length(), android.text.Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
            b.setSpan(new RelativeSizeSpan(1.35f),a,b.length(),33);
            b.setSpan(new StyleSpan(Typeface.BOLD),a,b.length(),33);

            b.append("\n\n🔴 SELL\n");
            a = b.length();
            b.append("Rp").append(rupiah(sell));
            b.setSpan(new RelativeSizeSpan(1.12f),a,b.length(),33);
            b.setSpan(new StyleSpan(Typeface.BOLD),a,b.length(),33);

            double spread = Math.abs(buy-sell);
            double pct = buy == 0 ? 0 : spread/buy*100.0;
            b.append("\n\nSPREAD   ");
            a = b.length();
            b.append(String.format(Locale.US,"%.2f%%",pct));
            b.setSpan(new RelativeSizeSpan(1.22f),a,b.length(),33);
            b.setSpan(new StyleSpan(Typeface.BOLD),a,b.length(),33);
        }

        display.setText(b);
        if (updateView != null) updateView.setText("Update: "+updated);
        if (statusView != null) statusView.setText("Status: "+status);
    }

    double parsePrice(Object value) {
        if (value == null) return 0;
        String digits = value.toString().replaceAll("[^0-9]","");
        if (digits.isEmpty()) return 0;
        try { return Double.parseDouble(digits); }
        catch (Exception e) { return 0; }
    }

    void connectPusher() {
        if (!active) return;
        if (client == null) {
            client = new OkHttpClient.Builder()
                .pingInterval(25,TimeUnit.SECONDS).build();
        }

        Request req = new Request.Builder()
            .url("wss://ws-ap1.pusher.com/app/52e99bd2c3c42e577e13?protocol=7&client=js&version=8.4.0&flash=false")
            .build();

        socket = client.newWebSocket(req,new WebSocketListener() {
            @Override public void onOpen(WebSocket ws,Response response) {
                handler.post(() -> {
                    if (!active) return;
                    status = "Terhubung; menunggu harga...";
                    render();
                });
            }

            @Override public void onMessage(WebSocket ws,String text) {
                try {
                    JSONObject msg = new JSONObject(text);
                    String event = msg.optString("event","");
                    if ("pusher:connection_established".equals(event)) {
                        JSONObject data = new JSONObject();
                        data.put("channel","gold-rate");
                        JSONObject sub = new JSONObject();
                        sub.put("event","pusher:subscribe");
                        sub.put("data",data);
                        ws.send(sub.toString());
                    } else if ("pusher:ping".equals(event)) {
                        JSONObject pong = new JSONObject();
                        pong.put("event","pusher:pong");
                        pong.put("data",new JSONObject());
                        ws.send(pong.toString());
                    } else if ("gold-rate-event".equals(event)) {
                        Object raw = msg.opt("data");
                        JSONObject d = raw instanceof JSONObject
                            ? (JSONObject)raw : new JSONObject(String.valueOf(raw));
                        double nb = parsePrice(d.opt("buying_rate"));
                        double ns = parsePrice(d.opt("selling_rate"));
                        String u = d.optString("created_at","-");
                        if (nb > 0 && ns > 0) handler.post(() -> {
                            if (!active) return;
                            previousBuy = buy; buy = nb; sell = ns; updated = u;
                            status = "Terhubung • LIVE";
                            render();
                        });
                    } else if ("pusher_internal:subscription_succeeded".equals(event)) {
                        handler.post(() -> {
                            if (!active) return;
                            status = "Channel aktif; menunggu harga...";
                            render();
                        });
                    }
                } catch (Exception ignored) {}
            }

            @Override public void onFailure(WebSocket ws,Throwable t,Response response) {
                handler.post(() -> {
                    if (!active) return;
                    status = "Koneksi terputus; mencoba ulang...";
                    render();
                    scheduleReconnect();
                });
            }

            @Override public void onClosed(WebSocket ws,int code,String reason) {
                handler.post(() -> {
                    if (!active) return;
                    status = "Koneksi ditutup; mencoba ulang...";
                    render();
                    scheduleReconnect();
                });
            }
        });
    }

    void scheduleReconnect() {
        if (!active) return;
        if (reconnect != null) handler.removeCallbacks(reconnect);
        reconnect = this::connectPusher;
        handler.postDelayed(reconnect,5000);
    }

    @Override protected void onDestroy() {
        active = false;
        handler.removeCallbacksAndMessages(null);
        if (socket != null) socket.close(1000,"Activity closed");
        if (client != null) client.dispatcher().executorService().shutdown();
        super.onDestroy();
    }
}
