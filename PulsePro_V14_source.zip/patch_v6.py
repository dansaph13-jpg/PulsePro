from pathlib import Path

main = Path("app/src/main/java/id/ts/overlay/MainActivity.java")
overlay = Path("app/src/main/java/id/ts/overlay/PriceOverlayService.java")

s = main.read_text()

replacements = [
    ('title.setText("TS GOLD  •  LIVE");',
     'title.setText("CUAN EXECUTOR");'),
    ('title.setTextSize(20);', 'title.setTextSize(22);'),
    ('root.setBackgroundColor(Color.rgb(17,24,39));',
     'root.setBackgroundColor(Color.rgb(11,18,32));'),
    ('bg.setColor(Color.rgb(20,29,40));',
     'bg.setColor(Color.rgb(18,30,48));'),
    ('bg.setStroke(dp(1),Color.rgb(190,155,70));',
     'bg.setStroke(dp(1),Color.rgb(43,57,77));'),
    ('root.addView(subtitle);',
     'subtitle.setVisibility(View.GONE);\n        root.addView(subtitle);'),
    ('panel.addView(timeRow);',
     'timeRow.setVisibility(View.GONE);\n        panel.addView(timeRow);'),
    ('panel.addView(updateView);',
     'updateView.setVisibility(View.GONE);\n        panel.addView(updateView);'),
    ('panel.addView(statusView);',
     'statusView.setVisibility(View.GONE);\n        panel.addView(statusView);'),
    ('root.addView(note);',
     'note.setVisibility(View.GONE);\n        root.addView(note);'),
    ('root.addView(footer,fp);',
     'footer.setVisibility(View.GONE);\n        root.addView(footer,fp);'),
    ('''b.append("\\n\\nSPREAD\\n");
            a = b.length();
            b.append("Rp").append(rupiah(spread))
             .append(" (").append(String.format(Locale.US,"%.2f",pct)).append("%)");''',
     '''b.append("\\n\\nSPREAD   ");
            a = b.length();
            b.append(String.format(Locale.US,"%.2f%%",pct));''')
]

for old, new in replacements:
    if old not in s:
        raise SystemExit("Pola MainActivity tidak ditemukan: " + repr(old))
    s = s.replace(old, new, 1)

main.write_text(s)
print("OK MainActivity")

s = overlay.read_text()

replacements = [
    ('root.setPadding(dp(12), dp(8), dp(12), dp(10));',
     'root.setPadding(dp(14), dp(12), dp(14), dp(14));'),
    ('bg.setColor(Color.rgb(20, 29, 40));',
     'bg.setColor(Color.rgb(18, 30, 48));'),
    ('bg.setStroke(dp(1), Color.rgb(190, 155, 70));',
     'bg.setStroke(dp(1), Color.rgb(43, 57, 77));'),
    ('title.setText("TS GOLD  •  LIVE");',
     'title.setText("CUAN EXECUTOR");'),
    ('title.setTextSize(16);', 'title.setTextSize(18);'),
    ('header.addView(clock);',
     'clock.setVisibility(View.GONE);\n        header.addView(clock);'),
    ('''b.append("\\n\\nSPREAD\\n");
            a = b.length();
            b.append("Rp").append(rupiah(Math.abs(spread)))
                .append(" (").append(String.format(Locale.US, "%.2f", pct)).append("%)");''',
     '''b.append("\\n\\nSPREAD   ");
            a = b.length();
            b.append(String.format(Locale.US, "%.2f%%", pct));'''),
    ('''            b.append("\\n\\nUpdate: ").append(updated);
            b.append("\\nStatus: ").append(status);
''', '')
]

for old, new in replacements:
    if old not in s:
        raise SystemExit("Pola Overlay tidak ditemukan: " + repr(old))
    s = s.replace(old, new, 1)

overlay.write_text(s)
print("OK PriceOverlayService")
