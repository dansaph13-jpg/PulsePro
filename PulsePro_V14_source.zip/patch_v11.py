from pathlib import Path

p = Path("app/src/main/java/id/ts/overlay/MainActivity.java")
s = p.read_text()

def replace_once(old, new, label):
    global s
    n = s.count(old)
    if n != 1:
        raise SystemExit(f"GAGAL: bagian {label} ditemukan {n} kali. File belum ditulis.")
    s = s.replace(old, new, 1)

replace_once(
    "TextView buyPriceView, buyDeltaView, sellPriceView, spreadView;",
    "TextView buyPriceView, buyDeltaView, sellPriceView, sellDeltaView, spreadView, newsSummary;",
    "deklarasi tampilan"
)

replace_once(
    "final ArrayDeque<PricePoint> priceHistory = new ArrayDeque<>();",
    "final ArrayDeque<PricePoint> priceHistory = new ArrayDeque<>();\n"
    "    final ArrayDeque<PricePoint> sellPriceHistory = new ArrayDeque<>();",
    "riwayat harga jual"
)

replace_once(
    "        sellCard.addView(sellPriceView);\n        rightColumn.addView(sellCard);",
    """        sellCard.addView(sellPriceView);

        sellDeltaView = new TextView(this);
        sellDeltaView.setText("Menunggu data");
        sellDeltaView.setTextColor(Color.LTGRAY);
        sellDeltaView.setTextSize(10);
        sellCard.addView(sellDeltaView);

        rightColumn.addView(sellCard);""",
    "indikator SELL"
)

replace_once(
    "        panel.addView(priceRow);",
    """        panel.addView(priceRow);

        newsSummary = new TextView(this);
        newsSummary.setText("US NEWS • Mengambil jadwal ekonomi AS...");
        newsSummary.setTextColor(Color.LTGRAY);
        newsSummary.setTextSize(12);
        newsSummary.setPadding(dp(2), dp(12), dp(2), dp(2));
        newsSummary.setOnClickListener(v -> openNews("weekly"));
        panel.addView(newsSummary);""",
    "panel US News"
)

replace_once(
    "        connectPusher();",
    "        connectPusher();\n        handler.post(mainNewsTick);",
    "pemanggilan berita"
)

replace_once(
    """    void render() {
        if (buyPriceView == null) return;""",
    """    final Runnable mainNewsTick = new Runnable() {
        @Override public void run() {
            if (!active) return;
            loadMainNews();
            handler.postDelayed(this, 60000L);
        }
    };

    void loadMainNews() {
        new Thread(() -> {
            String result = "US NEWS • Data kalender belum tersedia.";
            java.net.HttpURLConnection c = null;
            try {
                java.time.LocalDate today =
                    java.time.LocalDate.now(java.time.ZoneId.of("Asia/Jakarta"));
                java.net.URL url = new java.net.URL(
                    "https://www.financecalendar.com/wp-json/fc/v1/calendar"
                    + "?from=" + today + "&to=" + today.plusDays(7) + "&limit=200");
                c = (java.net.HttpURLConnection) url.openConnection();
                c.setConnectTimeout(10000);
                c.setReadTimeout(10000);
                c.setRequestProperty("Accept", "application/json");

                String raw;
                try (java.io.InputStream in = c.getInputStream();
                     java.io.ByteArrayOutputStream out = new java.io.ByteArrayOutputStream()) {
                    byte[] buf = new byte[4096];
                    int n;
                    while ((n = in.read(buf)) != -1) out.write(buf, 0, n);
                    raw = out.toString("UTF-8");
                }

                org.json.JSONObject rootJson = new org.json.JSONObject(raw);
                org.json.JSONArray events = rootJson.optJSONArray("events");
                if (events == null) events = rootJson.optJSONArray("data");

                StringBuilder b = new StringBuilder("🇺🇸 US NEWS • 7 HARI");
                int count = 0;
                if (events != null) {
                    for (int i = 0; i < events.length() && count < 3; i++) {
                        org.json.JSONObject e = events.optJSONObject(i);
                        if (e == null) continue;
                        String name = e.optString("title", e.optString("name", "US economic event"));
                        String key = (name + " " + e.optString("category", ""))
                            .toLowerCase(java.util.Locale.US);
                        if (!(key.contains("us ") || key.contains("u.s.")
                            || key.contains("united states") || key.contains("cpi")
                            || key.contains("inflation") || key.contains("payroll")
                            || key.contains("employment") || key.contains("jobless")
                            || key.contains("fomc") || key.contains("federal reserve")
                            || key.contains("pce") || key.contains("ppi")
                            || key.contains("gdp") || key.contains("retail sales")
                            || key.contains("ism") || key.contains("pmi")
                            || key.contains("jolts") || key.contains("consumer confidence")
                            || key.contains("durable goods") || key.contains("housing starts")))
                            continue;

                        String time = e.optString("time_utc", e.optString("date", "--"));
                        try {
                            time = java.time.format.DateTimeFormatter
                                .ofPattern("dd MMM HH:mm 'WIB'", new java.util.Locale("id", "ID"))
                                .withZone(java.time.ZoneId.of("Asia/Jakarta"))
                                .format(java.time.Instant.parse(time));
                        } catch (Exception ignored) {}

                        String impact = e.optString("impact", "--");
                        String prior = e.optString("prior", "--");
                        String forecast = e.optString("consensus", "--");
                        String actual = e.optString("actual", "--");
                        b.append("\\n\\n").append(name)
                            .append("\\n").append(time).append(" • ").append(impact)
                            .append("\\nPREV ").append(prior)
                            .append(" | PRED ").append(forecast)
                            .append(" | ACT ").append(actual);
                        count++;
                    }
                }
                if (count == 0) b.append("\\nBelum ada jadwal AS yang cocok.");
                b.append("\\nKetuk untuk analisis mingguan USD / XAUUSD.");
                result = b.toString();
            } catch (Exception ignored) {
                result = "🇺🇸 US NEWS • Gagal memuat data. Ketuk untuk membuka berita mingguan.";
            } finally {
                if (c != null) c.disconnect();
            }

            final String displayNews = result;
            handler.post(() -> {
                if (active && newsSummary != null) newsSummary.setText(displayNews);
            });
        }).start();
    }

    void recordSellPrice(double price) {
        long now = System.currentTimeMillis();
        sellPriceHistory.addLast(new PricePoint(now, price));
        while (!sellPriceHistory.isEmpty()
                && now - sellPriceHistory.peekFirst().time > 180000L)
            sellPriceHistory.removeFirst();
    }

    double sellMinuteReference() {
        long target = System.currentTimeMillis() - 60000L;
        PricePoint best = null;
        for (PricePoint p : sellPriceHistory) {
            if (p.time <= target) best = p;
            else break;
        }
        return best != null && target - best.time <= 65000L ? best.price : 0;
    }

    void render() {
        if (buyPriceView == null) return;""",
    "fungsi berita dan referensi SELL"
)

replace_once(
    "double ref = minuteReference();",
    "double ref = minuteReference();",
    "referensi BUY"
)

replace_once(
    """        buyPriceView.setTextColor(color);
        buyDeltaView.setTextColor(color);""",
    """        buyPriceView.setTextColor(color);
        buyDeltaView.setTextColor(color);

        double sellRef = sellMinuteReference();
        if (sellRef <= 0) {
            sellDeltaView.setText("Mengumpulkan data 1 menit");
            sellDeltaView.setTextColor(Color.rgb(245,200,90));
        } else {
            double sd = sell - sellRef;
            int sc = sd > 0 ? Color.rgb(0,255,160)
                : sd < 0 ? Color.rgb(255,90,95)
                : Color.rgb(245,200,90);
            String sa = sd > 0 ? "▲ +" : sd < 0 ? "▼ −" : "● ";
            sellDeltaView.setText(sa + "Rp" + rupiah(Math.abs(sd)) + " / 1 menit");
            sellDeltaView.setTextColor(sc);
        }""",
    "render SELL"
)

replace_once(
    "previousBuy = buy; buy = nb; recordPrice(nb); sell = ns; updated = u;",
    "previousBuy = buy; buy = nb; recordPrice(nb); sell = ns; recordSellPrice(ns); updated = u;",
    "perekaman harga SELL"
)

p.write_text(s)
print("PATCH OK: MainActivity.java")
