from pathlib import Path

p = Path("app/src/main/java/id/ts/overlay/PriceOverlayService.java")
s = p.read_text()

old_url = 'URL url = new URL("https://www.financecalendar.com/wp-json/fc/v1/today");'
assert old_url in s, "Endpoint lama tidak ditemukan"

s = s.replace(
    'String result = "US NEWS HARI INI\\nData berita belum tersedia."; ',
    'String result = "US NEWS 7 HARI\\nData berita belum tersedia.";'
)
s = s.replace(
    'URL url = new URL("https://www.financecalendar.com/wp-json/fc/v1/today");',
    '''java.time.LocalDate end = today.plusDays(7);
                URL url = new URL(
                    "https://www.financecalendar.com/wp-json/fc/v1/calendar"
                    + "?from=" + today + "&to=" + end + "&limit=200");'''
)
s = s.replace('"🇺🇸 US NEWS HARI INI\\n"', '"🇺🇸 US NEWS 7 HARI\\n"')
s = s.replace('i < events.length() && count < 2', 'i < events.length() && count < 12')
s = s.replace('"Waktu sumber: ").append(time)', '"Waktu WIB: ").append(toWib(time))')

# Tambahkan formatter waktu UTC ke WIB
marker = '    private void loadOverlayNews() {'
helper = '''    private String toWib(String value) {
        try {
            java.time.Instant instant = java.time.Instant.parse(value);
            java.time.format.DateTimeFormatter fmt =
                java.time.format.DateTimeFormatter.ofPattern(
                    "dd/MM HH:mm", java.util.Locale.getDefault())
                .withZone(java.time.ZoneId.of("Asia/Jakarta"));
            return fmt.format(instant) + " WIB";
        } catch (Exception ignored) {
            return value;
        }
    }

'''
assert marker in s, "Fungsi loadOverlayNews tidak ditemukan"
if 'private String toWib(String value)' not in s:
    s = s.replace(marker, helper + marker, 1)

s = s.replace('"US NEWS HARI INI\\nData berita belum tersedia."',
              '"US NEWS 7 HARI\\nData berita belum tersedia."')
s = s.replace('"🇺🇸 US NEWS HARI INI\\nFormat sumber berita belum dikenali."',
              '"🇺🇸 US NEWS 7 HARI\\nFormat sumber berita belum dikenali."')
s = s.replace('"🇺🇸 US NEWS HARI INI\\nData kalender belum dapat dimuat."',
              '"🇺🇸 US NEWS 7 HARI\\nData kalender belum dapat dimuat."')

p.write_text(s)
print("PATCH NEWS V10 BERHASIL")
