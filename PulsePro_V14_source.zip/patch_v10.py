from pathlib import Path
import re

base = Path("app/src/main/java/id/ts/overlay")
mp = base / "MainActivity.java"
sp = base / "PriceOverlayService.java"

m = mp.read_text()
s = sp.read_text()

# Pastikan source cocok sebelum melakukan perubahan
assert "double buy = 0, sell = 0, previousBuy = 0;" in m
assert "private double buy = 0, sell = 0, previousBuy = 0;" in s
assert "void render()" in m and "private void render()" in s

Path("backup_v10").mkdir(exist_ok=True)
Path("backup_v10/MainActivity.java").write_text(m)
Path("backup_v10/PriceOverlayService.java").write_text(s)

# MainActivity: riwayat harga
m = m.replace(
    "double buy = 0, sell = 0, previousBuy = 0;",
    """double buy = 0, sell = 0, previousBuy = 0;
    static class PricePoint {
        final long time;
        final double price;
        PricePoint(long t, double p) { time=t; price=p; }
    }
    final ArrayDeque<PricePoint> priceHistory = new ArrayDeque<>();""",
    1
)

helper_m = """
    void recordPrice(double price) {
        long now = System.currentTimeMillis();
        priceHistory.addLast(new PricePoint(now, price));
        while (!priceHistory.isEmpty()
                && now - priceHistory.peekFirst().time > 180000L)
            priceHistory.removeFirst();
    }

    double minuteReference() {
        long target = System.currentTimeMillis() - 60000L;
        PricePoint best = null;
        for (PricePoint p : priceHistory) {
            if (p.time <= target) best = p;
            else break;
        }
        return best != null && target - best.time <= 35000L
            ? best.price : 0;
    }

"""
m = m.replace("    void render() {", helper_m + "    void render() {", 1)

render_m = """    void render() {
        if (buyPriceView == null) return;
        if (buy <= 0 || sell <= 0) {
            buyPriceView.setText("Menunggu...");
            buyDeltaView.setText("Menunggu data");
            sellPriceView.setText("—");
            spreadView.setText("—");
            return;
        }

        buyPriceView.setText("Rp" + rupiah(buy));
        sellPriceView.setText("Rp" + rupiah(sell));
        spreadView.setText(String.format(Locale.US, "%.2f%%",
            Math.abs(buy-sell)/buy*100.0));

        double ref = minuteReference();
        int color;
        if (ref <= 0) {
            color = Color.rgb(245,200,90);
            buyDeltaView.setText("Mengumpulkan data 1 menit");
        } else {
            double d = buy-ref;
            color = d > 0 ? Color.rgb(0,255,160)
                : d < 0 ? Color.rgb(255,90,95)
                : Color.rgb(245,200,90);
            String arrow = d > 0 ? "▲ +" : d < 0 ? "▼ −" : "● ";
            buyDeltaView.setText(arrow + "Rp" + rupiah(Math.abs(d))
                + " / 1 menit");
        }

        buyPriceView.setTextColor(color);
        buyDeltaView.setTextColor(color);
        if (updateView != null) updateView.setText("Update: " + updated);
        if (statusView != null) statusView.setText("Status: " + status);
    }"""

m, n = re.subn(
    r"    void render\(\) \{.*?\n    \}",
    lambda _: render_m, m, count=1, flags=re.S
)
assert n == 1, "Render MainActivity gagal"

old_m = "previousBuy = buy; buy = nb; sell = ns; updated = u;"
assert old_m in m, "Update harga MainActivity tidak ditemukan"
m = m.replace(
    old_m,
    "previousBuy = buy; buy = nb; recordPrice(nb); sell = ns; updated = u;",
    1
)

# Overlay: riwayat harga
s = s.replace(
    "private double buy = 0, sell = 0, previousBuy = 0;",
    """private double buy = 0, sell = 0, previousBuy = 0;
    private static class PricePoint {
        final long time;
        final double price;
        PricePoint(long t, double p) { time=t; price=p; }
    }
    private final ArrayDeque<PricePoint> priceHistory = new ArrayDeque<>();""",
    1
)

helper_s = """
    private void recordPrice(double price) {
        long now = System.currentTimeMillis();
        priceHistory.addLast(new PricePoint(now, price));
        while (!priceHistory.isEmpty()
                && now - priceHistory.peekFirst().time > 180000L)
            priceHistory.removeFirst();
    }

    private double minuteReference() {
        long target = System.currentTimeMillis() - 60000L;
        PricePoint best = null;
        for (PricePoint p : priceHistory) {
            if (p.time <= target) best = p;
            else break;
        }
        return best != null && target - best.time <= 35000L
            ? best.price : 0;
    }

"""
s = s.replace("    private void render() {", helper_s + "    private void render() {", 1)

render_s = """    private void render() {
        if (buyPrice == null) return;
        if (buy <= 0 || sell <= 0) {
            buyPrice.setText("Menunggu harga...");
            buyPrice.setTextColor(Color.LTGRAY);
            buyDelta.setText("Mengumpulkan data harga");
            buyDelta.setTextColor(Color.GRAY);
            sellPrice.setText("—");
            spreadValue.setText("—");
            return;
        }

        buyPrice.setText("Rp" + rupiah(buy));
        sellPrice.setText("Rp" + rupiah(sell));
        spreadValue.setText(String.format(Locale.US, "%.2f%%",
            Math.abs(buy-sell)/buy*100.0));

        double ref = minuteReference();
        int color;
        if (ref <= 0) {
            color = Color.rgb(245,200,90);
            buyDelta.setText("Mengumpulkan data 1 menit");
        } else {
            double d = buy-ref;
            color = d > 0 ? Color.rgb(0,255,160)
                : d < 0 ? Color.rgb(255,90,95)
                : Color.rgb(245,200,90);
            String arrow = d > 0 ? "▲ +" : d < 0 ? "▼ −" : "● ";
            buyDelta.setText(arrow + "Rp" + rupiah(Math.abs(d))
                + " / 1 menit");
        }

        buyPrice.setTextColor(color);
        buyDelta.setTextColor(color);
    }"""

s, n = re.subn(
    r"    private void render\(\) \{.*?\n    \}",
    lambda _: render_s, s, count=1, flags=re.S
)
assert n == 1, "Render overlay gagal"

old_s = """previousBuy = buy;
                            buy = b;
                            sell = s;"""
assert old_s in s, "Update harga overlay tidak ditemukan"
s = s.replace(
    old_s,
    """previousBuy = buy;
                            buy = b;
                            recordPrice(b);
                            sell = s;""",
    1
)

mp.write_text(m)
sp.write_text(s)
print("PATCH HARGA V10 BERHASIL")
