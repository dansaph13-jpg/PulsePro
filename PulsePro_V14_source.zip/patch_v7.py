from pathlib import Path
import shutil

p = Path("app/src/main/java/id/ts/overlay/PriceOverlayService.java")
s = p.read_text()

backup = Path("backup_v6/PriceOverlayService.java")
if not backup.exists():
    raise SystemExit("Backup V6 tidak ditemukan. Patch dibatalkan.")

if "private TextView buyPrice;" in s:
    raise SystemExit("Komponen V7 terdeteksi. Patch tidak dijalankan ulang.")

def replace_method(src, signature, replacement):
    start = src.find(signature)
    if start < 0:
        raise SystemExit("Method tidak ditemukan: " + signature)
    brace = src.find("{", start)
    depth = 0
    in_string = False
    in_char = False
    escaped = False
    for i in range(brace, len(src)):
        c = src[i]
        if escaped:
            escaped = False
            continue
        if c == "\\" and (in_string or in_char):
            escaped = True
            continue
        if not in_char and c == '"':
            in_string = not in_string
            continue
        if not in_string and c == "'":
            in_char = not in_char
            continue
        if in_string or in_char:
            continue
        if c == "{":
            depth += 1
        elif c == "}":
            depth -= 1
            if depth == 0:
                return src[:start] + replacement + src[i+1:]
    raise SystemExit("Batas method tidak ditemukan: " + signature)

anchor = "private TextView display;"
if anchor not in s:
    raise SystemExit("Deklarasi display tidak ditemukan.")

# Backup tambahan sebelum perubahan
shutil.copy2(p, "PriceOverlayService.pre_v7.bak")

s = s.replace(anchor, anchor + """
    private TextView buyPrice;
    private TextView buyDelta;
    private TextView sellPrice;
    private TextView spreadValue;
""", 1)

add_overlay = r'''private void addOverlay() {
        int d = (int)(getResources().getDisplayMetrics().density + 0.5f);
        int navy = Color.rgb(11, 24, 37);
        int emerald = Color.rgb(27, 205, 145);
        int muted = Color.rgb(150, 171, 184);
        int white = Color.rgb(239, 247, 247);

        android.widget.LinearLayout root = new android.widget.LinearLayout(this);
        root.setOrientation(android.widget.LinearLayout.VERTICAL);
        root.setPadding(14*d, 12*d, 14*d, 13*d);

        android.graphics.drawable.GradientDrawable bg =
            new android.graphics.drawable.GradientDrawable();
        bg.setColor(navy);
        bg.setCornerRadius(16*d);
        bg.setStroke(Math.max(1, d), Color.rgb(34, 83, 70));
        root.setBackground(bg);

        android.widget.LinearLayout header = new android.widget.LinearLayout(this);
        header.setOrientation(android.widget.LinearLayout.HORIZONTAL);
        header.setGravity(Gravity.CENTER_VERTICAL);

        TextView title = new TextView(this);
        title.setText("TS GOLD  •  LIVE");
        title.setTextColor(emerald);
        title.setTextSize(12);
        title.setTypeface(null, Typeface.BOLD);
        header.addView(title, new android.widget.LinearLayout.LayoutParams(0, -2, 1));

        clock = new TextView(this);
        clock.setTextColor(muted);
        clock.setTextSize(12);
        clock.setTypeface(Typeface.MONOSPACE);
        header.addView(clock);

        TextView close = new TextView(this);
        close.setText("  ×");
        close.setTextColor(muted);
        close.setTextSize(22);
        close.setOnClickListener(v -> stopSelf());
        header.addView(close);
        root.addView(header);

        TextView buyLabel = new TextView(this);
        buyLabel.setText("BUY PRICE  ·  IDR");
        buyLabel.setTextColor(muted);
        buyLabel.setTextSize(10);
        android.widget.LinearLayout.LayoutParams labelLp =
            new android.widget.LinearLayout.LayoutParams(-2, -2);
        labelLp.topMargin = 13*d;
        root.addView(buyLabel, labelLp);

        buyPrice = new TextView(this);
        buyPrice.setText("Menunggu harga...");
        buyPrice.setTextColor(white);
        buyPrice.setTextSize(29);
        buyPrice.setTypeface(null, Typeface.BOLD);
        root.addView(buyPrice);

        buyDelta = new TextView(this);
        buyDelta.setText("● Menunggu data Treasury");
        buyDelta.setTextColor(muted);
        buyDelta.setTextSize(10);
        android.widget.LinearLayout.LayoutParams deltaLp =
            new android.widget.LinearLayout.LayoutParams(-2, -2);
        deltaLp.bottomMargin = 12*d;
        root.addView(buyDelta, deltaLp);

        android.widget.LinearLayout row = new android.widget.LinearLayout(this);
        row.setOrientation(android.widget.LinearLayout.HORIZONTAL);

        android.widget.LinearLayout sellCard = new android.widget.LinearLayout(this);
        sellCard.setOrientation(android.widget.LinearLayout.VERTICAL);
        sellCard.setPadding(10*d, 8*d, 5*d, 8*d);
        android.graphics.drawable.GradientDrawable cb1 =
            new android.graphics.drawable.GradientDrawable();
        cb1.setColor(Color.rgb(19, 40, 49));
        cb1.setCornerRadius(9*d);
        sellCard.setBackground(cb1);

        TextView sellLabel = new TextView(this);
        sellLabel.setText("SELL");
        sellLabel.setTextColor(muted);
        sellLabel.setTextSize(10);
        sellCard.addView(sellLabel);

        sellPrice = new TextView(this);
        sellPrice.setText("—");
        sellPrice.setTextColor(white);
        sellPrice.setTextSize(16);
        sellPrice.setTypeface(null, Typeface.BOLD);
        sellCard.addView(sellPrice);

        android.widget.LinearLayout spreadCard = new android.widget.LinearLayout(this);
        spreadCard.setOrientation(android.widget.LinearLayout.VERTICAL);
        spreadCard.setPadding(10*d, 8*d, 5*d, 8*d);
        android.graphics.drawable.GradientDrawable cb2 =
            new android.graphics.drawable.GradientDrawable();
        cb2.setColor(Color.rgb(19, 40, 49));
        cb2.setCornerRadius(9*d);
        spreadCard.setBackground(cb2);

        TextView spreadLabel = new TextView(this);
        spreadLabel.setText("SPREAD");
        spreadLabel.setTextColor(muted);
        spreadLabel.setTextSize(10);
        spreadCard.addView(spreadLabel);

        spreadValue = new TextView(this);
        spreadValue.setText("—");
        spreadValue.setTextColor(emerald);
        spreadValue.setTextSize(16);
        spreadValue.setTypeface(null, Typeface.BOLD);
        spreadCard.addView(spreadValue);

        android.widget.LinearLayout.LayoutParams lp1 =
            new android.widget.LinearLayout.LayoutParams(0, -2, 1);
        lp1.rightMargin = 4*d;
        row.addView(sellCard, lp1);

        android.widget.LinearLayout.LayoutParams lp2 =
            new android.widget.LinearLayout.LayoutParams(0, -2, 1);
        lp2.leftMargin = 4*d;
        row.addView(spreadCard, lp2);
        root.addView(row);

        newsDisplay = new TextView(this);
        newsDisplay.setTextColor(white);
        newsDisplay.setTextSize(11);
        newsDisplay.setLineSpacing(2*d, 1f);
        android.widget.LinearLayout.LayoutParams newsLp =
            new android.widget.LinearLayout.LayoutParams(-1, -2);
        newsLp.topMargin = 12*d;
        root.addView(newsDisplay, newsLp);

        panel = root;
        WindowManager.LayoutParams params = new WindowManager.LayoutParams(
            300*d, WindowManager.LayoutParams.WRAP_CONTENT,
            Build.VERSION.SDK_INT >= 26
                ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                : WindowManager.LayoutParams.TYPE_PHONE,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
                | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT);
        params.gravity = Gravity.TOP | Gravity.START;
        params.x = 10*d;
        params.y = 100*d;

        final int[] origin = new int[2];
        final float[] touch = new float[2];
        panel.setOnTouchListener((v, e) -> {
            if (e.getAction() == MotionEvent.ACTION_DOWN) {
                origin[0] = params.x;
                origin[1] = params.y;
                touch[0] = e.getRawX();
                touch[1] = e.getRawY();
                return true;
            }
            if (e.getAction() == MotionEvent.ACTION_MOVE) {
                params.x = origin[0] + (int)(e.getRawX() - touch[0]);
                params.y = origin[1] + (int)(e.getRawY() - touch[1]);
                try { wm.updateViewLayout(panel, params); }
                catch (Exception ignored) {}
                return true;
            }
            return e.getAction() == MotionEvent.ACTION_UP;
        });

        wm.addView(panel, params);
        render();
        handler.removeCallbacks(clockTick);
        handler.post(clockTick);
        handler.removeCallbacks(newsRefreshTask);
        handler.post(newsRefreshTask);
    }'''

render = r'''private void render() {
        if (buyPrice == null) return;

        if (buy <= 0) {
            buyPrice.setText("Menunggu harga...");
            buyPrice.setTextColor(Color.LTGRAY);
            buyDelta.setText("● Menunggu data Treasury");
            buyDelta.setTextColor(Color.GRAY);
            sellPrice.setText("—");
            spreadValue.setText("—");
            return;
        }

        buyPrice.setText(String.format(Locale.US, "%,.0f", buy));
        sellPrice.setText(String.format(Locale.US, "%,.0f", sell));
        double pct = buy > 0 ? Math.abs(buy - sell) / buy * 100.0 : 0;
        spreadValue.setText(String.format(Locale.US, "%.2f%%", pct));

        if (previousBuy > 0 && buy > previousBuy) {
            buyPrice.setTextColor(Color.rgb(35, 220, 145));
            buyDelta.setText("▲ HARGA NAIK");
            buyDelta.setTextColor(Color.rgb(35, 220, 145));
        } else if (previousBuy > 0 && buy < previousBuy) {
            buyPrice.setTextColor(Color.rgb(255, 90, 100));
            buyDelta.setText("▼ HARGA TURUN");
            buyDelta.setTextColor(Color.rgb(255, 90, 100));
        } else {
            buyPrice.setTextColor(Color.rgb(210, 224, 225));
            buyDelta.setText("● HARGA STABIL");
            buyDelta.setTextColor(Color.rgb(150, 171, 184));
        }
    }'''

s = replace_method(s, "private void addOverlay()", add_overlay)
s = replace_method(s, "private void render()", render)
p.write_text(s)
print("PATCH V7 BERHASIL DITERAPKAN")
print("Backup: PriceOverlayService.pre_v7.bak")
