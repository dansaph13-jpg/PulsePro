package id.ts.overlay;

import id.tsgold.pulsepro.R;

import android.app.*;
import android.os.*;
import android.content.*;
import android.graphics.*;
import android.graphics.drawable.GradientDrawable;
import android.provider.Settings;
import android.view.*;
import android.widget.*;
import org.json.JSONObject;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;
import okhttp3.WebSocket;
import okhttp3.WebSocketListener;
import java.net.*;
import java.io.*;
import java.text.NumberFormat;
import java.util.*;

public class PriceOverlayService extends Service {
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final ExecutorHolder worker = new ExecutorHolder();
    private WindowManager wm;
    private View panel;
    private TextView display;
    private TextView buyPrice;
    private TextView buyDelta;
    private TextView sellPrice;
    private TextView sellDelta;
    private TextView spreadValue;

    private TextView newsDisplay;
    private TextView clock;
    private boolean running = false;
    private OkHttpClient pusherClient;
    private WebSocket pusherSocket;
    private final Runnable reconnectTask = this::connectPusher;
    private double buy = 0, sell = 0, previousBuy = 0;
    private static class PricePoint {
        final long time;
        final double price;
        PricePoint(long t, double p) { time=t; price=p; }
    }
    private final ArrayDeque<PricePoint> priceHistory = new ArrayDeque<>();
    private final ArrayDeque<PricePoint> sellPriceHistory = new ArrayDeque<>();
    private String updated = "-", status = "Menunggu jadwal...";
    private static final String CHANNEL = "ts_overlay_channel";

    private final Runnable clockTick = new Runnable() {
        @Override public void run() {
            if (!running) return;
            if (clock != null) {
                clock.setText(new java.text.SimpleDateFormat(
                    "HH:mm:ss", java.util.Locale.getDefault()
                ).format(new java.util.Date()));
            }
            handler.postDelayed(this, 1000);
        }
    };

    static class ExecutorHolder {
        final java.util.concurrent.ExecutorService executor =
            java.util.concurrent.Executors.newSingleThreadExecutor();
    }

    @Override public void onCreate() {
        super.onCreate();
        createNotification();
        startForeground(7, buildNotification());

        if (!Settings.canDrawOverlays(this)) {
            stopSelf();
            return;
        }
        wm = (WindowManager)getSystemService(WINDOW_SERVICE);
        running = true;
        addOverlay();
        connectPusher();
    }

    private void createNotification() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel c = new NotificationChannel(
                CHANNEL, "TS Gold Overlay", NotificationManager.IMPORTANCE_LOW);
            ((NotificationManager)getSystemService(NOTIFICATION_SERVICE))
                .createNotificationChannel(c);
        }
    }

    private int dp(float n) {
        return (int)(n * getResources().getDisplayMetrics().density + 0.5f);
    }

    private void addOverlay() {
        int d = (int)(getResources().getDisplayMetrics().density + 0.5f);
        int navy = Color.rgb(5, 35, 29);
        int emerald = Color.rgb(0, 230, 150);
        int muted = Color.rgb(150, 171, 184);
        int white = Color.rgb(239, 247, 247);

        android.widget.LinearLayout root = new android.widget.LinearLayout(this);
        root.setOrientation(android.widget.LinearLayout.VERTICAL);
        root.setPadding(14*d, 12*d, 14*d, 13*d);

        android.graphics.drawable.GradientDrawable bg =
            new android.graphics.drawable.GradientDrawable();
        bg.setColor(navy);
        bg.setCornerRadius(16*d);
        bg.setStroke(Math.max(1, d), Color.rgb(0, 180, 115));
        root.setBackground(bg);

        android.widget.LinearLayout header = new android.widget.LinearLayout(this);
        header.setOrientation(android.widget.LinearLayout.HORIZONTAL);
        header.setGravity(Gravity.CENTER_VERTICAL);

        android.widget.ImageView logo = new android.widget.ImageView(this);
        logo.setImageResource(R.drawable.ic_ts_crown);
        logo.setScaleType(android.widget.ImageView.ScaleType.FIT_START);
        header.addView(logo,
            new android.widget.LinearLayout.LayoutParams(30*d, 30*d));
        root.addView(header);

        android.widget.LinearLayout priceRow =
            new android.widget.LinearLayout(this);
        priceRow.setOrientation(android.widget.LinearLayout.HORIZONTAL);
        priceRow.setGravity(Gravity.TOP);

        android.widget.LinearLayout buyCard =
            new android.widget.LinearLayout(this);
        buyCard.setOrientation(android.widget.LinearLayout.VERTICAL);
        buyCard.setPadding(7*d, 9*d, 3*d, 8*d);
        android.graphics.drawable.GradientDrawable buyBg =
            new android.graphics.drawable.GradientDrawable();
        buyBg.setColor(Color.rgb(5, 43, 33));
        buyBg.setCornerRadius(9*d);
        buyBg.setStroke(Math.max(1, d), Color.rgb(0, 180, 115));
        buyCard.setBackground(buyBg);

        buyPrice = new TextView(this);
        buyPrice.setText("Menunggu...");
        buyPrice.setTextColor(white);
        buyPrice.setTextSize(19);
        buyPrice.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
        buyPrice.setSingleLine(true);
        buyCard.addView(buyPrice);

        buyDelta = new TextView(this);
        buyDelta.setText("Menunggu data");
        buyDelta.setTextColor(muted);
        buyDelta.setTextSize(10);
        buyCard.addView(buyDelta);

        android.widget.LinearLayout.LayoutParams buyLp =
            new android.widget.LinearLayout.LayoutParams(0, -1, 1.22f);
        buyLp.rightMargin = 3*d;
        priceRow.addView(buyCard, buyLp);

        android.widget.LinearLayout rightColumn =
            new android.widget.LinearLayout(this);
        rightColumn.setOrientation(android.widget.LinearLayout.VERTICAL);

        android.widget.LinearLayout sellCard =
            new android.widget.LinearLayout(this);
        sellCard.setOrientation(android.widget.LinearLayout.VERTICAL);
        sellCard.setGravity(Gravity.CENTER_VERTICAL);
        sellCard.setPadding(3*d, 8*d, 2*d, 8*d);
        android.graphics.drawable.GradientDrawable sellBg =
            new android.graphics.drawable.GradientDrawable();
        sellBg.setColor(Color.rgb(10, 59, 45));
        sellBg.setCornerRadius(8*d);
        sellCard.setBackground(sellBg);

        sellPrice = new TextView(this);
        sellPrice.setText("—");
        sellPrice.setTextColor(white);
        sellPrice.setTextSize(12);
        sellPrice.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
        sellPrice.setSingleLine(true);
        sellCard.addView(sellPrice);

        sellDelta = new TextView(this);
        sellDelta.setText("Menunggu");
        sellDelta.setTextColor(muted);
        sellDelta.setTextSize(8);
        sellCard.addView(sellDelta);

        android.widget.LinearLayout.LayoutParams sellLp =
            new android.widget.LinearLayout.LayoutParams(-1, 0, 1f);
        rightColumn.addView(sellCard, sellLp);

        android.widget.LinearLayout bottomRow =
            new android.widget.LinearLayout(this);
        bottomRow.setOrientation(android.widget.LinearLayout.HORIZONTAL);
        bottomRow.setGravity(Gravity.CENTER_VERTICAL);
        bottomRow.setPadding(3*d, 0, 0, 0);

        spreadValue = new TextView(this);
        spreadValue.setText("—");
        spreadValue.setTextColor(emerald);
        spreadValue.setTextSize(11);
        spreadValue.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
        spreadValue.setSingleLine(true);
        bottomRow.addView(spreadValue,
            new android.widget.LinearLayout.LayoutParams(0, -2, 1f));

        clock = new TextView(this);
        clock.setTextColor(emerald);
        clock.setTextSize(10);
        clock.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
        clock.setSingleLine(true);
        bottomRow.addView(clock);

        TextView close = new TextView(this);
        close.setText(" ×");
        close.setTextColor(muted);
        close.setTextSize(18);
        close.setGravity(Gravity.CENTER);
        close.setOnClickListener(v -> hideOverlay());
        bottomRow.addView(close);

        android.widget.LinearLayout.LayoutParams bottomLp =
            new android.widget.LinearLayout.LayoutParams(-1, 27*d);
        bottomLp.topMargin = 2*d;
        rightColumn.addView(bottomRow, bottomLp);
        priceRow.addView(rightColumn,
            new android.widget.LinearLayout.LayoutParams(0, -1, 1f));

        android.widget.LinearLayout.LayoutParams priceRowLp =
            new android.widget.LinearLayout.LayoutParams(-1, 120*d);
        priceRowLp.topMargin = 9*d;
        root.addView(priceRow, priceRowLp);

        newsDisplay = new TextView(this);
        newsDisplay.setTextColor(white);
        newsDisplay.setTextSize(11);
        newsDisplay.setLineSpacing(2*d, 1f);
        android.widget.LinearLayout.LayoutParams newsLp =
            new android.widget.LinearLayout.LayoutParams(-1, -2);
        newsLp.topMargin = 12*d;
        root.addView(newsDisplay, newsLp);

        panel = root;
        WindowManager.LayoutParams params = new WindowManager.LayoutParams(
            300*d, WindowManager.LayoutParams.WRAP_CONTENT,
            Build.VERSION.SDK_INT >= 26
                ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                : WindowManager.LayoutParams.TYPE_PHONE,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
                | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT);
        params.gravity = Gravity.TOP | Gravity.START;
        params.x = 10*d;
        params.y = 100*d;

        final int[] origin = new int[2];
        final float[] touch = new float[2];
        panel.setOnTouchListener((v, e) -> {
            if (e.getAction() == MotionEvent.ACTION_DOWN) {
                origin[0] = params.x;
                origin[1] = params.y;
                touch[0] = e.getRawX();
                touch[1] = e.getRawY();
                return true;
            }
            if (e.getAction() == MotionEvent.ACTION_MOVE) {
                params.x = origin[0] + (int)(e.getRawX() - touch[0]);
                params.y = origin[1] + (int)(e.getRawY() - touch[1]);
                try { wm.updateViewLayout(panel, params); }
                catch (Exception ignored) {}
                return true;
            }
            return e.getAction() == MotionEvent.ACTION_UP;
        });

        wm.addView(panel, params);
        render();
        handler.removeCallbacks(clockTick);
        handler.post(clockTick);
        handler.removeCallbacks(newsRefreshTask);
        handler.post(newsRefreshTask);
    }


    private static String rupiah(double n) {
        return NumberFormat.getIntegerInstance(new Locale("id", "ID"))
            .format(Math.round(n));
    }


    private void recordPrice(double price) {
        long now = System.currentTimeMillis();
        priceHistory.addLast(new PricePoint(now, price));
        while (!priceHistory.isEmpty()
                && now - priceHistory.peekFirst().time > 180000L)
            priceHistory.removeFirst();
    }

    private void recordSellPrice(double price) {
        long now = System.currentTimeMillis();
        sellPriceHistory.addLast(new PricePoint(now, price));
        while (!sellPriceHistory.isEmpty()
                && now - sellPriceHistory.peekFirst().time > 180000L) {
            sellPriceHistory.removeFirst();
        }
    }

    private double sellMinuteReference() {
        long target = System.currentTimeMillis() - 60000L;
        PricePoint best = null;
        for (PricePoint p : sellPriceHistory) {
            if (p.time <= target) best = p;
            else break;
        }
        return best != null && target - best.time <= 65000L
                ? best.price : 0;
    }

    private double minuteReference() {
        long target = System.currentTimeMillis() - 60000L;
        PricePoint best = null;
        for (PricePoint p : priceHistory) {
            if (p.time <= target) best = p;
            else break;
        }
        return best != null && target - best.time <= 120000L
            ? best.price : 0;
    }

    private void render() {
        if (buyPrice == null) return;
        if (buy <= 0 || sell <= 0) {
            buyPrice.setText("Menunggu harga...");
            buyPrice.setTextColor(Color.rgb(239, 247, 247));
            buyDelta.setText("Mengumpulkan data harga");
            buyDelta.setTextColor(Color.GRAY);
            sellPrice.setText("—");
            sellDelta.setText("Menunggu data 1 menit");
            sellDelta.setTextColor(Color.GRAY);
            spreadValue.setText("—");
            return;
        }

        buyPrice.setText("Rp" + rupiah(buy));
        sellPrice.setText("Rp" + rupiah(sell));

        double sellRef = sellMinuteReference();
        int sellColor;
        if (sellRef <= 0) {
            sellColor = Color.rgb(245,200,90);
            sellDelta.setText("Mengumpulkan data 1 menit");
        } else {
            double sd = sell - sellRef;
            sellColor = sd > 0 ? Color.rgb(0,255,160)
                    : sd < 0 ? Color.rgb(255,90,95)
                    : Color.rgb(245,200,90);
            String sellArrow = sd > 0 ? "▲ +" : sd < 0 ? "▼ −" : "● ";
            sellDelta.setText(sellArrow + "Rp" + rupiah(Math.abs(sd))
                   );
        }
        sellPrice.setTextColor(Color.rgb(239, 247, 247));
        sellDelta.setTextColor(sellColor);

        spreadValue.setText(String.format(Locale.US, "%.2f%%",
            Math.abs(buy-sell)/buy*100.0));

        double ref = minuteReference();
        int color;
        if (ref <= 0) {
            color = Color.rgb(245,200,90);
            buyDelta.setText("Mengumpulkan data 1 menit");
        } else {
            double d = buy-ref;
            color = d > 0 ? Color.rgb(0,255,160)
                : d < 0 ? Color.rgb(255,90,95)
                : Color.rgb(245,200,90);
            String arrow = d > 0 ? "▲ +" : d < 0 ? "▼ −" : "● ";
            buyDelta.setText(arrow + "Rp" + rupiah(Math.abs(d))
               );
        }

        buyPrice.setTextColor(Color.rgb(239, 247, 247));
        buyDelta.setTextColor(color);
    }

    private final Runnable newsRefreshTask = new Runnable() {
        @Override public void run() {
            if (!running) return;
            loadOverlayNews();
            handler.postDelayed(this, 15 * 60 * 1000L);
        }
    };

    private String toWib(String value) {
        try {
            java.time.Instant instant = java.time.Instant.parse(value);
            java.time.format.DateTimeFormatter fmt =
                java.time.format.DateTimeFormatter.ofPattern(
                    "dd/MM HH:mm", java.util.Locale.getDefault())
                .withZone(java.time.ZoneId.of("Asia/Jakarta"));
            return fmt.format(instant) + " WIB";
        } catch (Exception ignored) {
            return value;
        }
    }

    private void loadOverlayNews() {
        String news = "NEWS\n"
            + "🇮🇩 CPI Indonesia — 14.30 WIB\n"
            + "A>F Rp 🟢, A<F Rp 🔴, A=F Rp ⚪\n\n"
            + "🇺🇸 PPI US — 19.30 WIB\n"
            + "A>F USD 🟢, XAU 🔴\n"
            + "A<F USD 🔴, XAU 🟢\n"
            + "\nMode manual • verifikasi jadwal sebelum digunakan.";
        if (newsDisplay != null) newsDisplay.setText(news);
    }

    private double parsePrice(Object value) {
        if (value == null) return 0;
        String digits = value.toString().replaceAll("[^0-9]", "");
        if (digits.isEmpty()) return 0;
        try { return Double.parseDouble(digits); }
        catch (Exception e) { return 0; }
    }

    private void connectPusher() {
        if (!running) return;
        handler.removeCallbacks(reconnectTask);
        status = "Menghubungkan Treasury...";
        render();

        if (pusherClient == null) {
            pusherClient = new OkHttpClient.Builder()
                .pingInterval(25, java.util.concurrent.TimeUnit.SECONDS)
                .build();
        }

        Request request = new Request.Builder()
            .url("wss://ws-ap1.pusher.com/app/52e99bd2c3c42e577e13?protocol=7&client=js&version=8.4.0&flash=false")
            .build();

        pusherSocket = pusherClient.newWebSocket(request, new WebSocketListener() {
            @Override public void onOpen(WebSocket ws, Response response) {
                handler.post(() -> {
                    if (!running) return;
                    status = "Tersambung; menunggu harga...";
                    render();
                });
            }

            @Override public void onMessage(WebSocket ws, String text) {
                try {
                    JSONObject msg = new JSONObject(text);
                    String event = msg.optString("event", "");

                    if ("pusher:connection_established".equals(event)) {
                        JSONObject sub = new JSONObject();
                        sub.put("event", "pusher:subscribe");
                        JSONObject data = new JSONObject();
                        data.put("channel", "gold-rate");
                        sub.put("data", data);
                        ws.send(sub.toString());
                    } else if ("pusher:ping".equals(event)) {
                        JSONObject pong = new JSONObject();
                        pong.put("event", "pusher:pong");
                        pong.put("data", new JSONObject());
                        ws.send(pong.toString());
                    } else if ("gold-rate-event".equals(event)) {
                        Object raw = msg.opt("data");
                        JSONObject data = raw instanceof JSONObject
                            ? (JSONObject) raw
                            : new JSONObject(String.valueOf(raw));
                        
                        double b = parsePrice(data.opt("buying_rate"));
                        double s = parsePrice(data.opt("selling_rate"));
                        String u = data.optString("created_at", "-");
                        if (b > 0 && s > 0) handler.post(() -> {
                            if (!running) return;
                            previousBuy = buy;
                            buy = b;
                            recordPrice(b);
                            sell = s;
                            recordSellPrice(s);
                            updated = u;
                            status = "Terhubung • LIVE";
                            render();
                            updateNotification();
                        });
                    } else if ("pusher_internal:subscription_succeeded".equals(event)) {
                        handler.post(() -> {
                            if (!running) return;
                            status = "Channel aktif; menunggu harga...";
                            render();
                        });
                    } else if ("pusher:subscription_error".equals(event)
                            || "pusher:error".equals(event)) {
                        handler.post(() -> {
                            if (!running) return;
                            status = "Koneksi ditolak";
                            render();
                        });
                    }
                } catch (Exception ignored) { }
            }

            @Override public void onFailure(WebSocket ws, Throwable t, Response response) {
                handler.post(() -> {
                    if (!running) return;
                    status = "Koneksi terputus; mencoba ulang...";
                    render();
                    scheduleReconnect();
                });
            }

            @Override public void onClosed(WebSocket ws, int code, String reason) {
                handler.post(() -> {
                    if (!running) return;
                    status = "Koneksi ditutup; mencoba ulang...";
                    render();
                    scheduleReconnect();
                });
            }
        });
    }

    private void scheduleReconnect() {
        if (running) {
            handler.removeCallbacks(reconnectTask);
            handler.postDelayed(reconnectTask, 5000);
        }
    }

    private void hideOverlay() {
        if (panel != null && wm != null) {
            try { wm.removeView(panel); } catch (Exception ignored) {}
        }
        panel = null;
        buyPrice = null;
        buyDelta = null;
        sellPrice = null;
        spreadValue = null;
        newsDisplay = null;
        clock = null;
    }

    private Notification buildNotification() {
        String line;
        if (buy > 0 && sell > 0) {
            double br = minuteReference();
            double sr = sellMinuteReference();
            String ba = br <= 0 ? "⚪" : buy > br ? "🟢" : buy < br ? "🔴" : "⚪";
            String sa = sr <= 0 ? "⚪" : sell > sr ? "🟢" : sell < sr ? "🔴" : "⚪";
            String sp = String.format(Locale.US, "%.2f%%",
                Math.abs(buy - sell) / buy * 100.0);
            String tm = new java.text.SimpleDateFormat(
                "HH.mm", Locale.getDefault()).format(new java.util.Date());
            line = rupiah(buy) + " " + ba + " | " + rupiah(sell) + " "
                + sa + " | " + sp + " | " + tm;
        } else {
            line = "Menunggu data harga Treasury";
        }

        Intent open = new Intent(this, MainActivity.class);
        int flags = PendingIntent.FLAG_UPDATE_CURRENT;
        if (Build.VERSION.SDK_INT >= 23) flags |= PendingIntent.FLAG_IMMUTABLE;

        Notification.Builder b = Build.VERSION.SDK_INT >= 26
            ? new Notification.Builder(this, CHANNEL)
            : new Notification.Builder(this);

        return b.setContentTitle(line)
            .setContentText(line)
            .setStyle(new Notification.BigTextStyle().bigText(line))
            .setSmallIcon(android.R.drawable.ic_menu_info_details)
            .setContentIntent(PendingIntent.getActivity(this, 0, open, flags))
            .setOnlyAlertOnce(true)
            .setOngoing(true)
            .build();
    }

    private void updateNotification() {
        NotificationManager nm =
            (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        if (nm != null) nm.notify(7, buildNotification());
    }

    @Override public int onStartCommand(Intent i, int flags, int startId) {
        if (running && panel == null && Settings.canDrawOverlays(this)) {
            addOverlay();
        }
        return START_STICKY;
    }

    @Override public void onDestroy() {
        running = false;
        handler.removeCallbacksAndMessages(null);
        worker.executor.shutdownNow();
        handler.removeCallbacks(reconnectTask);
        if (pusherSocket != null) {
            pusherSocket.close(1000, "Overlay dimatikan");
            pusherSocket = null;
        }
        if (pusherClient != null) {
            pusherClient.dispatcher().cancelAll();
            pusherClient.connectionPool().evictAll();
            pusherClient.dispatcher().executorService().shutdown();
            pusherClient = null;
        }
        if (panel != null && wm != null) {
            try { wm.removeView(panel); } catch (Exception ignored) {}
        }
        stopForeground(true);
        super.onDestroy();
    }

    @Override public IBinder onBind(Intent i) { return null; }
}
