from pathlib import Path

files = [
    Path("app/src/main/java/id/ts/overlay/MainActivity.java"),
    Path("app/src/main/java/id/ts/overlay/PriceOverlayService.java"),
]

for p in files:
    s = p.read_text()
    if p.name == "MainActivity.java":
        s = s.replace(
            "double buy = 0, sell = 0;",
            "double buy = 0, sell = 0, previousBuy = 0;"
        )
        s = s.replace(
            "buy = nb; sell = ns; updated = u;",
            "previousBuy = buy; buy = nb; sell = ns; updated = u;"
        )
    else:
        s = s.replace(
            "private double buy = 0, sell = 0;",
            "private double buy = 0, sell = 0, previousBuy = 0;"
        )
        s = s.replace(
            "buy = b;\n                            sell = s;",
            "previousBuy = buy;\n                            buy = b;\n                            sell = s;"
        )

    marker = 'b.append("Rp").append(rupiah(buy));'
    replacement = marker + '''
            int buyColor = previousBuy == 0 || buy == previousBuy
                ? Color.rgb(245, 200, 90)
                : (buy > previousBuy ? Color.rgb(65, 220, 145)
                                     : Color.rgb(255, 90, 95));
            b.setSpan(new android.text.style.ForegroundColorSpan(buyColor),
                a, b.length(), android.text.Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);'''

    if "ForegroundColorSpan(buyColor)" not in s:
        if marker not in s:
            raise SystemExit("Bagian BUY tidak ditemukan: " + str(p))
        s = s.replace(marker, replacement, 1)

    p.write_text(s)
    print("OK:", p)
