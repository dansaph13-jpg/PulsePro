from pathlib import Path

p = Path("app/src/main/java/id/ts/overlay/PriceOverlayService.java")
s = p.read_text()

def replace_once(old, new, label):
    global s
    if old not in s:
        raise SystemExit("GAGAL: bagian " + label + " tidak ditemukan. File tidak disimpan.")
    s = s.replace(old, new, 1)
    print("OK:", label)

replace_once(
    "private TextView sellPrice;",
    "private TextView sellPrice;\n    private TextView sellDelta;",
    "deklarasi SELL"
)

replace_once(
    "private final ArrayDeque<PricePoint> priceHistory = new ArrayDeque<>();",
    "private final ArrayDeque<PricePoint> priceHistory = new ArrayDeque<>();\n"
    "    private final ArrayDeque<PricePoint> sellPriceHistory = new ArrayDeque<>();",
    "histori SELL"
)

replace_once(
    "        sellCard.addView(sellPrice);\n        rightColumn.addView(sellCard);",
    """        sellCard.addView(sellPrice);

        sellDelta = new TextView(this);
        sellDelta.setText("Menunggu data 1 menit");
        sellDelta.setTextColor(muted);
        sellDelta.setTextSize(9);
        sellCard.addView(sellDelta);

        rightColumn.addView(sellCard);""",
    "tampilan perubahan SELL"
)

replace_once(
    "    private double minuteReference() {",
    """    private void recordSellPrice(double price) {
        long now = System.currentTimeMillis();
        sellPriceHistory.addLast(new PricePoint(now, price));
        while (!sellPriceHistory.isEmpty()
                && now - sellPriceHistory.peekFirst().time > 180000L) {
            sellPriceHistory.removeFirst();
        }
    }

    private double sellMinuteReference() {
        long target = System.currentTimeMillis() - 60000L;
        PricePoint best = null;
        for (PricePoint p : sellPriceHistory) {
            if (p.time <= target) best = p;
            else break;
        }
        return best != null && target - best.time <= 65000L
                ? best.price : 0;
    }

    private double minuteReference() {""",
    "fungsi histori SELL"
)

replace_once(
    '            sellPrice.setText("—");\n            spreadValue.setText("—");',
    '            sellPrice.setText("—");\n'
    '            sellDelta.setText("Menunggu data 1 menit");\n'
    '            sellDelta.setTextColor(Color.GRAY);\n'
    '            spreadValue.setText("—");',
    "status menunggu harga"
)

replace_once(
    '        sellPrice.setText("Rp" + rupiah(sell));\n'
    '        spreadValue.setText(String.format(Locale.US, "%.2f%%",',
    '''        sellPrice.setText("Rp" + rupiah(sell));

        double sellRef = sellMinuteReference();
        int sellColor;
        if (sellRef <= 0) {
            sellColor = Color.rgb(245,200,90);
            sellDelta.setText("Mengumpulkan data 1 menit");
        } else {
            double sd = sell - sellRef;
            sellColor = sd > 0 ? Color.rgb(0,255,160)
                    : sd < 0 ? Color.rgb(255,90,95)
                    : Color.rgb(245,200,90);
            String sellArrow = sd > 0 ? "▲ +" : sd < 0 ? "▼ −" : "● ";
            sellDelta.setText(sellArrow + "Rp" + rupiah(Math.abs(sd))
                    + " / 1 menit");
        }
        sellPrice.setTextColor(sellColor);
        sellDelta.setTextColor(sellColor);

        spreadValue.setText(String.format(Locale.US, "%.2f%%",''',
    "kalkulasi perubahan SELL"
)

replace_once(
    "                            sell = s;",
    "                            sell = s;\n                            recordSellPrice(s);",
    "perekaman harga SELL"
)

p.write_text(s)
print("PATCH SELL BERHASIL")
